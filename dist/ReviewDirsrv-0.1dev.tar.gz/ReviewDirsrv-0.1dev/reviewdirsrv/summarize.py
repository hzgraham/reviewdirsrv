#!/usr/bin/env python
import sys, os

def usage():
    print """Usage: sumarize [--init, -i|--check, -ch|--clean, -cl]
    --init, -i          

    Examples:

       Initialize:

"""

