reviewdirsrv
============

analyze directory server data
